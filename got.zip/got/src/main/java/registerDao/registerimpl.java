package registerDao;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import Model.Product;
import Model.Register;


import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Transactional
@Repository
public class registerimpl implements registerinterface {

	List<Register> user;
	
	 @Autowired
	 SessionFactory sessionFactory;
	public List<Register> getAlluser() {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Register> getuser(String s) {
		// TODO Auto-generated method stub
		return null;
	}

	public void adduser(Register p) {
		// TODO Auto-generated method stub
		System.out.println("In save");
		//Session s=sessionFactory.getCurrentSession();
	   
	   Session session = sessionFactory.openSession();
	    Transaction tx = (Transaction) session.beginTransaction();
		System.out.println("After current");
		session.save(p);
		 tx.commit();
		 Serializable id = session.getIdentifier(p);
		    session.close();
	}

	public Register getRowById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	public int updateRow(Register p) {
		// TODO Auto-generated method stub
		return 0;
	}

	public int deleteRow(String email) {
		// TODO Auto-generated method stub
		return 0;
	}

}
