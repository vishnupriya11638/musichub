package registerDao;

import java.util.List;
import Model.Register;



public interface registerinterface {
	public List<Register> getAlluser();

	public List<Register> getuser(String s);
	public void adduser(Register p);

	public Register getRowById(int id);

	public int updateRow(Register p);

	public int deleteRow(String email);

}
