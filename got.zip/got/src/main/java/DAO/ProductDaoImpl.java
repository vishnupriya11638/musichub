package DAO;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;



import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import Model.Product;

@Transactional
@Repository
public class ProductDaoImpl implements ProductDao {
	List<Product> prods;
	
	 @Autowired
	 SessionFactory sessionFactory;

	   public ProductDaoImpl(){
		   
	   }
	   
	
	   
	 
	   public List<Product> getAllproduct() 
	   {
		  
		    
		   Session session = sessionFactory.getCurrentSession();  
	    Query q =session.createQuery("from Product");
	    	prods =(List<Product>)q.list();
	    	return prods;
	   }
	   
	   public void addproduct(Product p)
	   {
		   System.out.println("In save");
			//Session s=sessionFactory.getCurrentSession();
		   
		   Session session = sessionFactory.openSession();
		    Transaction tx = (Transaction) session.beginTransaction();
			System.out.println("After current");
			session.save(p);
			 tx.commit();
			 Serializable id = session.getIdentifier(p);
			    session.close();

	   }
	 
	   public Product getRowById(int id) {
	    Session session = sessionFactory.openSession();
	    Product p = (Product) session.load(Product.class, id);
	    return p;
	   }

	   public int updateRow(Product p) {
	    Session session = sessionFactory.openSession();
	    Transaction tx = (Transaction) session.beginTransaction();
	    session.saveOrUpdate(p);
	    tx.commit();
	    Serializable id = session.getIdentifier(p);
	    session.close();
	    return (Integer) id;
	   }

	   public int deleteRow(int id) {
	    Session session = sessionFactory.openSession();
	    Transaction tx = session.beginTransaction();
	    Product p = (Product) session.load(Product.class, id);
	    session.delete(p);
	    tx.commit();
	    Serializable ids = session.getIdentifier(p);
	    session.close();
	    return (Integer) ids;
	   }




	public List<Product> getproduct(String s) {
		// TODO Auto-generated method stub
		return null;
	}
}
