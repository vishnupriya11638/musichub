package Registerimpl;
import java.util.List;
import Model.Register;
import Model.Product;
public interface regservice {
	public List<Register> getAll();
	public void create(Register u);
	 public Product getRowById(int id);
	 public int updateRow(Register p);
	 public int deleteRow(String email);

}
