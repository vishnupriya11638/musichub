package Registerimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import Model.Product;
import Model.Register;
import registerDao.registerinterface;

public class regserviceimpl implements regservice{
	@Autowired
	   registerinterface pdi;

	public List<Register> getAll() {
		// TODO Auto-generated method stub
		return null;
	}

	public void create(Register u) {
		// TODO Auto-generated method stub
		pdi.adduser(u);
		
	}

	public Product getRowById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	public int updateRow(Register p) {
		// TODO Auto-generated method stub
		return 0;
	}

	public int deleteRow(String email) {
		// TODO Auto-generated method stub
		return 0;
	}

}
