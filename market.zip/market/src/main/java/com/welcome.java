package com;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller

public class welcome {
	@RequestMapping("login")
	public ModelAndView showMessage(){
		ModelAndView mv=new ModelAndView("login");
		System.out.println("hi");
		return mv;
	}
	
	@RequestMapping("welcome")
	public ModelAndView showMessage1(
			@RequestParam(value = "$email", required = true, defaultValue = "email") String name) {
		ModelAndView mv = new ModelAndView("welcome");
		mv.addObject("email", name);
		return mv;
	}
	@RequestMapping("register")
	public ModelAndView showMessage2(
			@RequestParam(value = "$email", required = true, defaultValue = "email") String name){
		ModelAndView mv=new ModelAndView("register");
		return mv;
	}

}
