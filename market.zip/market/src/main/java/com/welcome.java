package com;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller

public class welcome {

	 
	@RequestMapping("/login")
	public ModelAndView showMessage(){
		ModelAndView mv=new ModelAndView("login");
		return mv;
	}
	@RequestMapping("/register")
	public ModelAndView showMessage2(
			@RequestParam(value="" )){
		ModelAndView mvc=new ModelAndView("register");
		return mvc;
	}
	@RequestMapping("/welcome")
	public ModelAndView showMessage1(
			@RequestParam(value = "$email", required = true, defaultValue = "Guest") String name) {
		ModelAndView mv = new ModelAndView("welcome");
		mv.addObject("$email", name);
		return mv;
	}

}
